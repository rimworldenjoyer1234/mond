Updated v2 scripts with load generator fallback and validation path fix.
