#!/usr/bin/env bash
set -euo pipefail

. ./invoke_testing_helper.sh

BASE_OUTDIR="${OUTDIR:-../results-measurements}/load_sweep"
VALIDATION_SCRIPT="${VALIDATION_SCRIPT:-../validation-runtime/processdata_load_sweep.sh}"
VALIDATION_OUTDIR="${VALIDATION_OUTDIR:-../results-analysis-runtime/load_sweep}"
RUN_VALIDATION="${RUN_VALIDATION:-1}"
LOAD_LIST="${LOAD_LIST:-0 1 2 4 6 8}"
PROBE_CPU="${PROBE_CPU:-0}"
STRESS_CPU_START="${STRESS_CPU_START:-1}"
WARMUP_SECS="${WARMUP_SECS:-3}"
JENT_EXTRA_ARGS="${JENT_EXTRA_ARGS:-}"
CPU_BURNER="${CPU_BURNER:-auto}"

command -v taskset >/dev/null 2>&1 || {
  echo "ERROR: taskset is required"
  exit 1
}

CORES="$(nproc)"
if [ "$CORES" -lt 1 ]; then
  echo "ERROR: could not detect CPU count"
  exit 1
fi

mkdir -p "$BASE_OUTDIR" "$VALIDATION_OUTDIR"
trap 'make -s -f Makefile.hashtime clean >/dev/null 2>&1 || true' EXIT
make -s -f Makefile.hashtime

build_cmdopts() {
  local -a opts
  opts=(--max-mem "$MAX_MEMORY_SIZE")
  if [ -n "${FORCE_NOTIME_NOISE_SOURCE:-}" ]; then
    opts+=(--disable-internal-timer)
  fi
  if [ -n "$JENT_EXTRA_ARGS" ]; then
    # shellcheck disable=SC2206
    local extra=( $JENT_EXTRA_ARGS )
    opts+=("${extra[@]}")
  fi
  printf '%s\n' "${opts[@]}"
}

pick_loadgen() {
  if [ "$CPU_BURNER" = "stress-ng" ]; then
    printf 'stress-ng\n'
    return 0
  fi
  if [ "$CPU_BURNER" = "sha256sum" ]; then
    printf 'sha256sum\n'
    return 0
  fi
  if [ "$CPU_BURNER" = "yes" ]; then
    printf 'yes\n'
    return 0
  fi
  if command -v stress-ng >/dev/null 2>&1; then
    printf 'stress-ng\n'
  elif command -v sha256sum >/dev/null 2>&1; then
    printf 'sha256sum\n'
  else
    printf 'yes\n'
  fi
}

spawn_load_workers() {
  local bg="$1"
  local cpu_range="$2"
  local log_file="$3"
  local mode
  mode="$(pick_loadgen)"
  local -a pids=()
  local i

  case "$mode" in
    stress-ng)
      taskset -c "$cpu_range" \
        stress-ng --cpu "$bg" --cpu-method all --metrics-brief --timeout 1h \
        >"$log_file" 2>&1 &
      pids+=("$!")
      ;;
    sha256sum)
      : > "$log_file"
      for (( i=0; i<bg; i++ )); do
        (
          cpu=$(( STRESS_CPU_START + i ))
          taskset -c "$cpu" bash -lc 'while :; do head -c 1048576 /dev/zero | sha256sum >/dev/null; done'
        ) >>"$log_file" 2>&1 &
        pids+=("$!")
      done
      ;;
    yes)
      : > "$log_file"
      for (( i=0; i<bg; i++ )); do
        (
          cpu=$(( STRESS_CPU_START + i ))
          taskset -c "$cpu" bash -lc 'while :; do yes >/dev/null; done'
        ) >>"$log_file" 2>&1 &
        pids+=("$!")
      done
      ;;
    *)
      echo "ERROR: unknown CPU burner: $mode" >&2
      return 1
      ;;
  esac

  printf '%s\n' "$mode"
  printf '%s\n' "${pids[@]}"
}

run_case() {
  local bg_requested="$1"
  local bg_max=$(( CORES - 1 ))
  local bg="$bg_requested"
  if [ "$bg" -gt "$bg_max" ]; then
    bg="$bg_max"
  fi

  local case_dir="$BASE_OUTDIR/bg_${bg_requested}"
  local probe_dir="$case_dir/probe"
  local probe_log="$case_dir/probe.log"
  local stress_log="$case_dir/stress.log"
  local meta_file="$case_dir/metadata.env"
  mkdir -p "$probe_dir"

  local -a worker_pids=()
  local load_mode="none"
  if [ "$bg" -gt 0 ]; then
    local stress_end=$(( STRESS_CPU_START + bg - 1 ))
    if [ "$stress_end" -ge "$CORES" ]; then
      stress_end=$(( CORES - 1 ))
    fi
    if [ "$STRESS_CPU_START" -le "$stress_end" ]; then
      local stress_range="${STRESS_CPU_START}-${stress_end}"
      mapfile -t load_info < <(spawn_load_workers "$bg" "$stress_range" "$stress_log")
      load_mode="${load_info[0]}"
      if [ "${#load_info[@]}" -gt 1 ]; then
        worker_pids=("${load_info[@]:1}")
      fi
      sleep "$WARMUP_SECS"
    fi
  fi

  mapfile -t cmdopts < <(build_cmdopts)
  {
    printf 'bg_requested=%s\n' "$bg_requested"
    printf 'bg_effective=%s\n' "$bg"
    printf 'probe_cpu=%s\n' "$PROBE_CPU"
    printf 'cores=%s\n' "$CORES"
    printf 'num_events=%s\n' "$NUM_EVENTS"
    printf 'force_notime=%s\n' "${FORCE_NOTIME_NOISE_SOURCE:-0}"
    printf 'jent_extra_args=%s\n' "$JENT_EXTRA_ARGS"
    printf 'load_mode=%s\n' "$load_mode"
  } > "$meta_file"

  set +e
  taskset -c "$PROBE_CPU" "$JENT_HASHTIME" \
    "$NUM_EVENTS" 1 "$probe_dir/$NONIID_DATA" "${cmdopts[@]}" \
    >"$probe_log" 2>&1
  local rc=$?
  set -e

  if [ "${#worker_pids[@]}" -gt 0 ]; then
    kill "${worker_pids[@]}" >/dev/null 2>&1 || true
    wait "${worker_pids[@]}" >/dev/null 2>&1 || true
  fi

  if [ "$rc" -ne 0 ]; then
    echo "ERROR: probe failed for bg=${bg_requested}; see $probe_log"
    return "$rc"
  fi
}

for bg in $LOAD_LIST; do
  echo "=== load sweep: background workers=$bg ==="
  run_case "$bg"
done

if [ "$RUN_VALIDATION" = "1" ]; then
  echo "=== running validation ==="
  "$VALIDATION_SCRIPT" "$BASE_OUTDIR" "$VALIDATION_OUTDIR"
fi
