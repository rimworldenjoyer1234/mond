#!/usr/bin/env bash
set -euo pipefail

. ./invoke_testing_helper.sh

BASE_OUTDIR="${OUTDIR:-../results-measurements}/concurrency"
VALIDATION_SCRIPT="${VALIDATION_SCRIPT:-../validation-runtime/processdata_concurrency.sh}"
VALIDATION_OUTDIR="${VALIDATION_OUTDIR:-../results-analysis-runtime/concurrency}"
RUN_VALIDATION="${RUN_VALIDATION:-1}"
P_LIST="${P_LIST:-1 2 4 6 8 12 16 24}"
WARMUP_SECS="${WARMUP_SECS:-0}"
JENT_EXTRA_ARGS="${JENT_EXTRA_ARGS:-}"

command -v taskset >/dev/null 2>&1 || {
  echo "ERROR: taskset is required"
  exit 1
}

CORES="$(nproc)"
if [ "$CORES" -lt 1 ]; then
  echo "ERROR: could not detect CPU count"
  exit 1
fi

mkdir -p "$BASE_OUTDIR" "$VALIDATION_OUTDIR"
trap 'make -s -f Makefile.hashtime clean >/dev/null 2>&1 || true' EXIT
make -s -f Makefile.hashtime

build_cmdopts() {
  local -a opts
  opts=(--max-mem "$MAX_MEMORY_SIZE")
  if [ -n "${FORCE_NOTIME_NOISE_SOURCE:-}" ]; then
    opts+=(--disable-internal-timer)
  fi
  if [ -n "$JENT_EXTRA_ARGS" ]; then
    # shellcheck disable=SC2206
    local extra=( $JENT_EXTRA_ARGS )
    opts+=("${extra[@]}")
  fi
  printf '%s\n' "${opts[@]}"
}

run_parallel_case() {
  local p="$1"
  local case_dir="$BASE_OUTDIR/p_${p}"
  local meta_file="$case_dir/metadata.env"
  mkdir -p "$case_dir"

  {
    printf 'parallel_instances=%s\n' "$p"
    printf 'cores=%s\n' "$CORES"
    printf 'num_events=%s\n' "$NUM_EVENTS"
    printf 'force_notime=%s\n' "${FORCE_NOTIME_NOISE_SOURCE:-0}"
    printf 'jent_extra_args=%s\n' "$JENT_EXTRA_ARGS"
  } > "$meta_file"

  mapfile -t cmdopts < <(build_cmdopts)
  local -a pids
  local -a logs

  local i
  for (( i=0; i<p; i++ )); do
    local cpu=$(( i % CORES ))
    local inst_dir="$case_dir/inst_${i}"
    local inst_log="$case_dir/inst_${i}.log"
    mkdir -p "$inst_dir"
    {
      printf 'instance=%s\n' "$i"
      printf 'cpu=%s\n' "$cpu"
    } > "$case_dir/inst_${i}.env"

    taskset -c "$cpu" "$JENT_HASHTIME" \
      "$NUM_EVENTS" 1 "$inst_dir/$NONIID_DATA" "${cmdopts[@]}" \
      >"$inst_log" 2>&1 &
    pids+=("$!")
    logs+=("$inst_log")
  done

  if [ "$WARMUP_SECS" -gt 0 ]; then
    sleep "$WARMUP_SECS"
  fi

  local rc=0
  for i in "${!pids[@]}"; do
    if ! wait "${pids[$i]}"; then
      echo "ERROR: instance $i failed for p=$p; see ${logs[$i]}"
      rc=1
    fi
  done
  return "$rc"
}

for p in $P_LIST; do
  echo "=== concurrency sweep: parallel instances=$p ==="
  run_parallel_case "$p"
done

if [ "$RUN_VALIDATION" = "1" ]; then
  echo "=== running validation ==="
  "$VALIDATION_SCRIPT" "$BASE_OUTDIR" "$VALIDATION_OUTDIR"
fi
