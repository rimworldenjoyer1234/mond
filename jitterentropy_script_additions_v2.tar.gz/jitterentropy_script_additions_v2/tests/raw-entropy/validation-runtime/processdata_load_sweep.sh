#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PROCESSDATA_SH="${PROCESSDATA_SH:-$SCRIPT_DIR/processdata.sh}"
DATA_ROOT_INPUT="${1:-../results-measurements/load_sweep}"
RESULTS_ROOT_INPUT="${2:-../results-analysis-runtime/load_sweep}"
DATA_ROOT="$(realpath -m "$DATA_ROOT_INPUT")"
RESULTS_ROOT="$(realpath -m "$RESULTS_ROOT_INPUT")"
SUMMARY_FILE="$RESULTS_ROOT/load_sweep_summary.tsv"

mkdir -p "$RESULTS_ROOT"

extract_metric() {
  local metric_file="$1"
  awk -F': *' '
    /^H_original:/ { h_original=$2 }
    /^H_bitstring:/ { h_bitstring=$2 }
    /^min\(H_original, 8 X H_bitstring\):/ { minval=$2 }
    END {
      printf "%s\t%s\t%s\n", h_original, h_bitstring, minval
    }
  ' "$metric_file"
}

count_health_flags() {
  local log_file="$1"
  if [ ! -f "$log_file" ]; then
    printf '0\t0\t0\n'
    return 0
  fi
  awk '
    /RCT/ { rct++ }
    /APT/ { apt++ }
    /Lag/ { lag++ }
    END {
      printf "%d\t%d\t%d\n", rct+0, apt+0, lag+0
    }
  ' "$log_file"
}

run_processdata() {
  local sample_dir="$1"
  local result_dir="$2"
  (
    cd "$SCRIPT_DIR"
    "$PROCESSDATA_SH" "$sample_dir" "$result_dir" >/dev/null
  )
}

printf 'bg_requested\tbg_effective\tH_original\tH_bitstring\tH_min\tRCT\tAPT\tLag\tsample_dir\tresults_dir\n' > "$SUMMARY_FILE"

shopt -s nullglob
for probe_dir in "$DATA_ROOT"/bg_*/probe; do
  case_dir="$(dirname "$probe_dir")"
  case_name="$(basename "$case_dir")"
  result_dir="$RESULTS_ROOT/$case_name/probe"
  mkdir -p "$result_dir"

  run_processdata "$probe_dir" "$result_dir"

  metric_file="$result_dir/jent-raw-noise-0001.minentropy_FF_8bits.txt"
  if [ ! -f "$metric_file" ]; then
    echo "WARNING: missing $metric_file" >&2
    continue
  fi

  IFS=$'\t' read -r h_original h_bitstring h_min < <(extract_metric "$metric_file")
  IFS=$'\t' read -r rct apt lag < <(count_health_flags "$case_dir/probe.log")

  bg_requested="${case_name#bg_}"
  bg_effective="$bg_requested"
  if [ -f "$case_dir/metadata.env" ]; then
    # shellcheck disable=SC1090
    . "$case_dir/metadata.env"
  fi

  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$bg_requested" "$bg_effective" "$h_original" "$h_bitstring" "$h_min" \
    "$rct" "$apt" "$lag" "$probe_dir" "$result_dir" >> "$SUMMARY_FILE"
done

echo "Wrote $SUMMARY_FILE"
